// Implement Touch Button highlighting
// Test on screen reader

'use-strict';

var config = {
    apiKey: "AIzaSyDPVLhPUPjtNhxscoegYeoING93Ylnhtz0",
    authDomain: "eventscreator-94c20.firebaseapp.com",
    databaseURL: "https://eventscreator-94c20.firebaseio.com",
    storageBucket: "eventscreator-94c20.appspot.com",
    messagingSenderId: "625565515542"
};

var registerLink = document.querySelector('#register-button');
var registerForm = document.querySelector('.register-form');
var loginForm = document.querySelector('.login-form');
var eventsForm = document.querySelector('.events-form');
var cardContainer = document.querySelector('.card-container');
var signOut = document.querySelector('#sign-out');
var registerEmail = document.querySelector('.register-email');
var registerPassword = document.querySelector('.register-password');
var loginEmail = document.querySelector('.login-email');
var loginPassword = document.querySelector('.login-password');
var addGuests = document.querySelector('.add-guests');
var eventGuestList = document.querySelector('.event-guest-list');
var guestList = [];
var birthdateIssues;
var passwordIssues;

$('#password-req').popover();

firebase.initializeApp(config);

// Firebase init configured

/**
 * A class for instantiating different types of issues related to input field validation.
 * eg : password issues, username issues
 */
function Issue() {
    this.issueList = [];
}

Issue.prototype = {
    add : function(message) {
        this.issueList.push(message);
    },
    retrieve : function() {
        return this.issueList.reduce(function(final, msg) {
            return final + '<li>' + msg + '</li>';
        },'');
    },
    hasIssues : function() {
        return this.issueList.length > 0
    }
}

/**
 * Bind listeners to all buttons
 */
function bindListeners() {
    var previousValue;
    $('.event').on('focus', function () {
        previousValue = this.value;
    }).change(function() {
        if(previousValue === "" || this.value === "") {
            changeProgress(this.value);
        }
    });

    $('.register-password').focusout(function(){
        validatePassword(this.value);
    });
    $('.register-birthdate').focusout(function(){
        validateBirthdate(this.value);
    });
    $('.register-password').focus(function(){
        $('.password-issue-card').empty();
    });
    $('.register-birthdate').focus(function(){
        $('.birthdate-issue-card').empty();
    });

    loginForm.onsubmit = function(e) {
        loginButton = $('.login-submit');
        loginButton.toggleClass('loading');
        firebase.auth().signInWithEmailAndPassword(loginEmail.value, loginPassword.value).catch(function(error) {
            var errorCode = error.code;
            var errorMessage = error.message;
            throw new Error(errorMessage);
        }).then(function() {
            loginButton.toggleClass('loading');
        });
        e.preventDefault();
    }

    registerLink.onclick = function() {
        loginForm.style.display = loginForm.style.display === 'none' ? '' : 'none';
        registerForm.style.display = registerForm.style.display === 'none' ? '' : 'none';
    }

    registerForm.onsubmit = function(e) {
        registerButton = $('.register-submit');
        registerButton.toggleClass('loading');
        if((birthdateIssues && birthdateIssues.hasIssues()) || (passwordIssues && passwordIssues.hasIssues())) {
            throw new Error('You are having issues.');
        }
        firebase.auth().createUserWithEmailAndPassword(registerEmail.value, registerPassword.value).catch(function(error) {
            var errorCode = error.code;
            var errorMessage = error.message;
            throw new Error(errorMessage);
        }).then(function() {
            firebase.database().ref('users/' + firebase.auth().currentUser.uid).set({
              email: registerEmail.value,
            });
            registerButton.toggleClass('loading');
        }.bind(this));

        e.preventDefault();
    }

    eventsForm.onsubmit = function(e) {
        var event = {};
        event.eventName = document.querySelector('.event-name');
        event.eventHost = document.querySelector('.event-host');
        event.eventLocation = document.querySelector('.event-location');
        event.eventStart = document.querySelector('.event-start-date-time');
        event.eventGuests = guestList;
        event.eventType = document.querySelector('.event-type');
        event.eventEnd = document.querySelector('.event-end-date-time');
        validateEventForm(event);
        addEventToDatabase(event);
        e.preventDefault();
    }

    signOut.onclick = function(e) {
        firebase.auth().signOut()
            .then(function() {
                eventsForm.style.display = 'none';
                $('.card-container').empty();
                loginForm.style.display = '';
            });
    }

    addGuests.onclick = function() {
        var guestName = eventGuestList.value;
        if(guestName) {
            guestList.push(guestName);
            var guestNameCard = document.createElement('div');
            guestNameCard.className = 'col-sm-4 guestNameCard';
            var htmlData = '<div>' + guestName + '</div>';
            guestNameCard.innerHTML = htmlData;
            $('.guests-container').append(guestNameCard);
            $('.event-guest-list').parent().css('margin-bottom', '0px')
        }
    }


}

bindListeners();

firebase.auth().onAuthStateChanged(firebaseUser => {
    if(firebaseUser) {
        eventsForm.style.display =  '';
        registerForm.style.display = 'none';
        loginForm.style.display = 'none';
        console.log(firebaseUser);
        const dbRefObject = firebase.database().ref().child(firebaseUser.uid);
        const dbRefList = dbRefObject.child('events');
        dbRefList.on('child_added', function(snap) {
            snaps = snap.val();
            var card = document.createElement('div');
            card.className = 'col-sm-12 event-cards';
            var guests = snaps.guestList.reduce(function(acc, guest) {
                return acc + '<h4>' + guest + '</h4>';
            },'')
            var htmlData= '<div><button class="btn glyphicon glyphicon-remove close" id=' + snap.key + ' onload=""></button><h2>' + snaps.name + '</h2><h3>' + snaps.host + '</h3><p>' + snaps.location+' </p><h3>Start : ' + snaps.start + '</h3><h3>End : ' + snaps.end + '</h3><p>Guests Invited: </p>' + guests + '</div>'
            card.innerHTML = htmlData;
            cardContainer.appendChild(card);
            $('.event-cards').find('.close').click(function() {
                var eventKey = this.id;
                this.parentElement.parentElement.remove();
                firebase.database().ref(firebase.auth().currentUser.uid + '/events/' + eventKey).remove();
            });
        });
    } else {
        console.log('User not logged in.');
    }
});

function validatePassword(password) {

    passwordIssues = new Issue();

    if (password.length < 8) {
        passwordIssues.add("Password is fewer than 8 characters");
    } else if (password.length > 100) {
        passwordIssues.add("Password is greater than 100 characters");
    }
    if (!password.match(/[\!\@\#\$\%\^\&\*]/g)) {
        passwordIssues.add("Missing a symbol (!, @, #, $, %, ^, &, *)");
    }
    if (!password.match(/\d/g)) {
        passwordIssues.add("Missing a number");
    }
    if (!password.match(/[a-z]/g)) {
        passwordIssues.add("Missing a lowercase letter");
    }
    if (!password.match(/[A-Z]/g)) {
        passwordIssues.add("Missing an uppercase letter");
    }

    var illegalCharacterGroup = password.match(/[^A-z0-9\!\@\#\$\%\^\&\*]/g)
    if (illegalCharacterGroup) {
        illegalCharacterGroup.forEach(function (illegalChar) {
            passwordIssues.add("Includes illegal character: " + illegalChar);
        });
    }

    if(passwordIssues.hasIssues()){
        createIssueCard('password', passwordIssues);
    }

    return passwordIssues;
}

function validateBirthdate(birthdate) {

    birthdateIssues = new Issue();

    if(Date.now() < new Date(birthdate)) {
        birthdateIssues.add('You are too young to create events :(');
    }
    if(parseInt(birthdate.split('-')[0]) < 1900) {
        birthdateIssues.add('You are too old to create events :(');
    }
    if(birthdateIssues.hasIssues()){
        createIssueCard('birthdate', birthdateIssues);
    }

    return birthdateIssues;

}

function validateEventForm(event) {
    var eventIssues = new Issue();
    var eventName = event.eventName.value;
    var eventHost = event.eventHost.value;
    var eventLocation = event.eventLocation.value;
    var eventStart = event.eventStart.value;
    var eventEnd = event.eventEnd.value;

}

function addEventToDatabase(event) {
    var newEventKey = firebase.database().ref().child('events').push().key;
    firebase.database().ref(firebase.auth().currentUser.uid + '/events/' + newEventKey).set({
        host : event.eventHost.value,
        name : event.eventName.value,
        type : event.eventType.value,
        guestList : event.eventGuests,
        location : event.eventLocation.value,
        start : event.eventStart.value,
        end : event.eventEnd.value
    }).then(function() {
        eventsForm.reset();
        $('.progress').width(0);
        $('html, body').animate({ scrollTop: $(document).height() }, 'slow');
        $('.guests-container').empty();
    });

}

function createIssueCard(inputName, eventIssues) {
    var issueBoard = document.createElement('div');
    issueBoard.className = 'col-sm-12 '+ inputName +'-issue-card';
    var htmlData = eventIssues.retrieve();
    issueBoard.innerHTML = htmlData;
    $('#register-'+inputName).parent().after(issueBoard);
}

function changeProgress(val) {
    var progress = $('.progress');
    var progressWidth = progress.width();
    var progressBarWidth = $('.progress-bar').width()
    var percentWidth = (progressWidth*100)/progressBarWidth;
    percentWidth = val === '' ? percentWidth - (100/7) : percentWidth + (100/7);
    progress.width(percentWidth+'%')
}
